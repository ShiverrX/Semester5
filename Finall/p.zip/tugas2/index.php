<?php

include "Classes/Mammal.php";
include "Classes/Bird.php";

use Zoo\Mammal;
use Zoo\Bird;

$mammal = new Mammal("Lion", 5, "Roaring");
echo displayOutput($mammal);

$bird = new Bird("Parrot", 2, "Colorful");
echo displayOutput($bird);

function displayOutput($animal)
{
    $output = "<div style='border: 2px solid #333; padding: 10px; margin-bottom: 10px;'>";
    $output .= "<strong>{$animal->summonSpirit()}</strong>";
    $output .= "</div>";

    return $output;
}
