<?php

namespace Zoo;

trait Greet
{
    public function greet()
    {
        return "Hello! ";
    }
}
