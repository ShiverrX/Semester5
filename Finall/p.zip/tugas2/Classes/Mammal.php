<?php

namespace Zoo;

include "Animal.php";
include "Traits/Greet.php";

class Mammal extends Animal
{
    use Greet;

    private $specialAbility;

    public function __construct($name, $age, $specialAbility)
    {
        parent::__construct($name, $age);
        $this->specialAbility = $specialAbility;
    }

    public function summonSpirit()
    {
        return $this->greet() . "I am a mammal named $this->name, $this->age years old, and my special ability is $this->specialAbility.";
    }
}
